# -*- coding: utf-8 -*-
"""
Created on Mon Jul  1 17:43:32 2024

@author: Lorenzo
"""

import numpy
import pca
import lda

def vcol(x): # Same as in pca script
    return x.reshape((x.size, 1))

def vrow(x): # Same as in pca script
    return x.reshape((1, x.size))

import scipy.special

def load(fname):
    DList = []
    labelsList = []
    hLabels = {
        '0': 0,
        '1': 1
        }

    with open(fname) as f:
        for line in f:
            try:
                attrs = line.split(',')[0:-1]
                attrs = vcol(numpy.array([float(i) for i in attrs]))
                name = line.split(',')[-1].strip()
                label = hLabels[name]
                DList.append(attrs)
                labelsList.append(label)
            except:
                pass

    return numpy.hstack(DList), numpy.array(labelsList, dtype=numpy.int32)

def split_db_2to1(D, L, seed=0):
    
    nTrain = int(D.shape[1]*2.0/3.0)
    numpy.random.seed(seed)
    idx = numpy.random.permutation(D.shape[1])
    idxTrain = idx[0:nTrain]
    idxTest = idx[nTrain:]
    
    DTR = D[:, idxTrain]
    DVAL = D[:, idxTest]
    LTR = L[idxTrain]
    LVAL = L[idxTest]
    
    return (DTR, LTR), (DVAL, LVAL)

def compute_mu_C(D):
    mu = vcol(D.mean(1))
    C = ((D-mu) @ (D-mu).T) / float(D.shape[1])
    return mu, C

def logpdf_GAU_ND(x, mu, C):
    P = numpy.linalg.inv(C)
    return -0.5*x.shape[0]*numpy.log(numpy.pi*2) - 0.5*numpy.linalg.slogdet(C)[1] - 0.5 * ((x-mu) * (P @ (x-mu))).sum(0)

# Compute a dictionary of ML parameters for each class
def Gau_MVG_ML_estimates(D, L):
    labelSet = set(L)
    hParams = {}
    for lab in labelSet:
        DX = D[:, L==lab]
        hParams[lab] = compute_mu_C(DX)
    return hParams

# Compute a dictionary of ML parameters for each class - Naive Bayes version of the model
# We compute the full covariance matrix and then extract the diagonal. Efficient implementations would work directly with just the vector of variances (diagonal of the covariance matrix)
def Gau_Naive_ML_estimates(D, L):
    labelSet = set(L)
    hParams = {}
    for lab in labelSet:
        DX = D[:, L==lab]
        mu, C = compute_mu_C(DX)
        hParams[lab] = (mu, C * numpy.eye(D.shape[0]))
    return hParams

# Compute a dictionary of ML parameters for each class - Tied Gaussian model
# We exploit the fact that the within-class covairance matrix is a weighted mean of the covraince matrices of the different classes
def Gau_Tied_ML_estimates(D, L):
    labelSet = set(L)
    hParams = {}
    hMeans = {}
    CGlobal = 0
    for lab in labelSet:
        DX = D[:, L==lab]
        mu, C_class = compute_mu_C(DX)
        CGlobal += C_class * DX.shape[1]
        hMeans[lab] = mu
    CGlobal = CGlobal / D.shape[1]
    for lab in labelSet:
        hParams[lab] = (hMeans[lab], CGlobal)
    return hParams

# Compute per-class log-densities. We assume classes are labeled from 0 to C-1. The parameters of each class are in hParams (for class i, hParams[i] -> (mean, cov))
def compute_log_likelihood_Gau(D, hParams):

    S = numpy.zeros((len(hParams), D.shape[1]))
    for lab in range(S.shape[0]):
        S[lab, :] = logpdf_GAU_ND(D, hParams[lab][0], hParams[lab][1])
    return S

# compute log-postorior matrix from log-likelihood matrix and prior array
def compute_logPosterior(S_logLikelihood, v_prior):
    SJoint = S_logLikelihood + vcol(numpy.log(v_prior))
    SMarginal = vrow(scipy.special.logsumexp(SJoint, axis=0))
    SPost = SJoint - SMarginal
    return SPost

def mvg_naive_bayes(D,L):
    (DTR, LTR), (DVAL, LVAL) = split_db_2to1(D, L)
    hParams_MVG = Gau_MVG_ML_estimates(DTR, LTR)
    LLR = logpdf_GAU_ND(DVAL, hParams_MVG[1][0], hParams_MVG[1][1]) - logpdf_GAU_ND(DVAL, hParams_MVG[0][0], hParams_MVG[0][1])

    PVAL = numpy.zeros(DVAL.shape[1], dtype=numpy.int32)
    TH = 0
    PVAL[LLR >= TH] = 1
    PVAL[LLR < TH] = 0
    print("MVG - Error rate: %.1f%%" % ((PVAL != LVAL).sum() / float(LVAL.size) * 100))     
    
    hParams_Tied = Gau_Naive_ML_estimates(DTR, LTR)
    LLR = logpdf_GAU_ND(DVAL, hParams_Tied[1][0], hParams_Tied[1][1]) - logpdf_GAU_ND(DVAL, hParams_Tied[0][0], hParams_Tied[0][1])

    PVAL = numpy.zeros(DVAL.shape[1], dtype=numpy.int32)
    TH = 0
    PVAL[LLR >= TH] = 1
    PVAL[LLR < TH] = 0
    print("Naive Bayes - Error rate: %.1f%%" % ((PVAL != LVAL).sum() / float(LVAL.size) * 100))     

    hParams_Tied = Gau_Tied_ML_estimates(DTR, LTR)
    LLR = logpdf_GAU_ND(DVAL, hParams_Tied[1][0], hParams_Tied[1][1]) - logpdf_GAU_ND(DVAL, hParams_Tied[0][0], hParams_Tied[0][1])

    PVAL = numpy.zeros(DVAL.shape[1], dtype=numpy.int32)
    TH = 0
    PVAL[LLR >= TH] = 1
    PVAL[LLR < TH] = 0
    print("Bayes Tied - Error rate: %.1f%%" % ((PVAL != LVAL).sum() / float(LVAL.size) * 100))     


if __name__ == '__main__':
    D, L = load("trainData.txt")
    
    # 2-Class problem
    (DTR, LTR), (DVAL, LVAL) = split_db_2to1(D, L)
    hParams_MVG = Gau_MVG_ML_estimates(DTR, LTR)
    print ("True Class:")
    print (hParams_MVG[1][1])
    
    print ("False Class:")
    print (hParams_MVG[0][1])
    
    Corr1 = hParams_MVG[1][1] / ( vcol(hParams_MVG[1][1].diagonal()**0.5) * vrow(hParams_MVG[1][1].diagonal()**0.5) )
    Corr2 = hParams_MVG[0][1] / ( vcol(hParams_MVG[0][1].diagonal()**0.5) * vrow(hParams_MVG[0][1].diagonal()**0.5) )
    
    print ("Correlation for True")
    print (Corr1)
    print ("Correlation for False")
    print (Corr2)
    print("Base classification:")
    mvg_naive_bayes(D, L)
    print("\n")
    
    #FILTERED
    D_filtered = D[:-2]
    print("Removed last 2 features:")
    mvg_naive_bayes(D_filtered, L)
    print("\n")
    #FEATURES 1-2
    D_filtered = D[:-4]
    print("Features 1-2:")
    mvg_naive_bayes(D_filtered, L)
    print("\n")
    #FEATURES 3-4
    D_filtered = D[2:-2, :]
    print("Features 3-4:")
    mvg_naive_bayes(D_filtered, L)
    print("\n")
    
    #PCA Preprocessing
    (DTR, LTR), (DVAL, LVAL) = split_db_2to1(D, L)
    m = 2
    UPCA = pca.compute_pca(DTR, m = m) # Estimated only on model training data
    DTR = pca.apply_pca(UPCA, DTR)   # Applied to original model training data
    DVAL = pca.apply_pca(UPCA, DVAL) # Applied to original validation data

    hParams_MVG = Gau_MVG_ML_estimates(DTR, LTR)
    LLR = logpdf_GAU_ND(DVAL, hParams_MVG[1][0], hParams_MVG[1][1]) - logpdf_GAU_ND(DVAL, hParams_MVG[0][0], hParams_MVG[0][1])
    
    PVAL = numpy.zeros(DVAL.shape[1], dtype=numpy.int32)
    TH = 0
    PVAL[LLR >= TH] = 1
    PVAL[LLR < TH] = 0
    print('PCA MVG Error rate: %.1f%%' % ( (PVAL != LVAL).sum() / float(LVAL.size) *100 ))
    
    
    hParams_Tied = Gau_Naive_ML_estimates(DTR, LTR)
    LLR = logpdf_GAU_ND(DVAL, hParams_Tied[1][0], hParams_Tied[1][1]) - logpdf_GAU_ND(DVAL, hParams_Tied[0][0], hParams_Tied[0][1])

    PVAL = numpy.zeros(DVAL.shape[1], dtype=numpy.int32)
    TH = 0
    PVAL[LLR >= TH] = 1
    PVAL[LLR < TH] = 0
    print("PCA Naive Bayes - Error rate: %.1f%%" % ((PVAL != LVAL).sum() / float(LVAL.size) * 100))     

    hParams_Tied = Gau_Tied_ML_estimates(DTR, LTR)
    LLR = logpdf_GAU_ND(DVAL, hParams_Tied[1][0], hParams_Tied[1][1]) - logpdf_GAU_ND(DVAL, hParams_Tied[0][0], hParams_Tied[0][1])

    PVAL = numpy.zeros(DVAL.shape[1], dtype=numpy.int32)
    TH = 0
    PVAL[LLR >= TH] = 1
    PVAL[LLR < TH] = 0
    print("PCA Bayes Tied - Error rate: %.1f%%" % ((PVAL != LVAL).sum() / float(LVAL.size) * 100))     

    #Corr = C / ( vcol(C.diagonal()**0.5) * vrow(C.diagonal()**0.5) )
    