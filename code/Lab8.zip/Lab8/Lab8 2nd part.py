
import numpy
import scipy.special
import sklearn.datasets
import Utils
import bayesRisk

import matplotlib.pyplot as plt

def vcol(x):
    return x.reshape((x.size, 1))

def vrow(x):
    return x.reshape((1, x.size))

def plot_hist(D, L):

    D1 = D[:, L==0]
    D2 = D[:, L==1]

    hFea = {
        0: 'Prova',
        }

    for dIdx in range(1):
        plt.figure()
        plt.xlabel(hFea[dIdx])
        plt.xscale(log, base=10)
        plt.hist(D1[dIdx, :], bins = 20, density = True, alpha = 0.4, label = 'True')
        plt.hist(D2[dIdx, :], bins = 20, density = True, alpha = 0.4, label = 'False')
        
        plt.legend()
        plt.tight_layout() # Use with non-default font size to keep axis label inside the figure
        #plt.savefig('hist_%d.pdf' % dIdx)
    plt.show()


# Optimize the logistic regression loss
def trainLogRegBinary(DTR, LTR, l):

    ZTR = LTR * 2.0 - 1.0 # We do it outside the objective function, since we only need to do it once

    def logreg_obj_with_grad(v): # We compute both the objective and its gradient to speed up the optimization
        w = v[:-1]
        b = v[-1]
        s = numpy.dot(vcol(w).T, DTR).ravel() + b

        loss = numpy.logaddexp(0, -ZTR * s)

        G = -ZTR / (1.0 + numpy.exp(ZTR * s))
        GW = (vrow(G) * DTR).mean(1) + l * w.ravel()
        Gb = G.mean()
        return loss.mean() + l / 2 * numpy.linalg.norm(w)**2, numpy.hstack([GW, numpy.array(Gb)])

    vf = scipy.optimize.fmin_l_bfgs_b(logreg_obj_with_grad, x0 = numpy.zeros(DTR.shape[0]+1))[0]
    print ("Log-reg - lambda = %e - J*(w, b) = %e" % (l, logreg_obj_with_grad(vf)[0]))
    return vf[:-1], vf[-1]

# Optimize the weighted logistic regression loss
def trainWeightedLogRegBinary(DTR, LTR, l, pT):

    ZTR = LTR * 2.0 - 1.0 # We do it outside the objective function, since we only need to do it once
    
    wTrue = pT / (ZTR>0).sum() # Compute the weights for the two classes
    wFalse = (1-pT) / (ZTR<0).sum()

    def logreg_obj_with_grad(v): # We compute both the objective and its gradient to speed up the optimization
        w = v[:-1]
        b = v[-1]
        s = numpy.dot(vcol(w).T, DTR).ravel() + b

        loss = numpy.logaddexp(0, -ZTR * s)
        loss[ZTR>0] *= wTrue # Apply the weights to the loss computations
        loss[ZTR<0] *= wFalse

        G = -ZTR / (1.0 + numpy.exp(ZTR * s))
        G[ZTR > 0] *= wTrue # Apply the weights to the gradient computations
        G[ZTR < 0] *= wFalse
        
        GW = (vrow(G) * DTR).sum(1) + l * w.ravel()
        Gb = G.sum()
        return loss.sum() + l / 2 * numpy.linalg.norm(w)**2, numpy.hstack([GW, numpy.array(Gb)])

    vf = scipy.optimize.fmin_l_bfgs_b(logreg_obj_with_grad, x0 = numpy.zeros(DTR.shape[0]+1))[0]
    print ("Weighted Log-reg (pT %e) - lambda = %e - J*(w, b) = %e" % (pT, l, logreg_obj_with_grad(vf)[0]))
    return vf[:-1], vf[-1]


if __name__ == '__main__':
    
    D, L = Utils.load("trainData.txt")
    
    minDCF_list = []
    actDCF_list = []
    
    # 2-Class problem
    (DTR, LTR), (DVAL, LVAL) = Utils.split_db_2to1(D, L)
    DTR = DTR[:, ::50]
    LTR = LTR[::50]
    logspace = numpy.logspace(-4, 2, 13)
    
    best_minDCF = float('inf')
    best_lambda = None
    
    for lamb in logspace:
        w, b = trainLogRegBinary(DTR, LTR, lamb) # Train model
        sVal = numpy.dot(w.T, DVAL) + b # Compute validation scores
        PVAL = (sVal > 0) * 1 # Predict validation labels - sVal > 0 returns a boolean array, multiplying by 1 (integer) we get an integer array with 0's and 1's corresponding to the original True and False values
        err = (PVAL != LVAL).sum() / float(LVAL.size)
        print('Error rate: %.1f' % (err * 100))
        
        # Compute empirical prior
        pEmp = (LTR == 1).sum() / LTR.size
        # Compute LLR-like scores
        pT = 0.1
        w, b = trainWeightedLogRegBinary(DTR, LTR, lamb, pT=pT) # Train model to print the loss
        sVal = numpy.dot(w.T, DVAL) + b
        sValLLR = sVal - numpy.log(pT / (1 - pT))
        minDCF = bayesRisk.compute_minDCF_binary_fast(sValLLR, LVAL, pT, 1.0, 1.0)
        actDCF = bayesRisk.compute_actDCF_binary_fast(sValLLR, LVAL, pT, 1.0, 1.0)
        
        minDCF_list.append(minDCF)
        actDCF_list.append(actDCF)
        
        print('minDCF - pT = 0.1: %.4f' % minDCF)
        print('actDCF - pT = 0.1: %.4f' % actDCF)
        print()
        
        # Check for best minDCF
        if minDCF < best_minDCF:
            best_minDCF = minDCF
            best_lambda = lamb
    
    print('Best minDCF: %.4f with lambda = %.4e' % (best_minDCF, best_lambda))
    
    plt.figure(figsize=(10, 6))
    plt.semilogx(logspace, minDCF_list, label='minDCF')
    plt.semilogx(logspace, actDCF_list, label='actDCF')
    plt.xlabel('Lambda')
    plt.ylabel('DCF')
    plt.title('minDCF e actDCF in funzione di Lambda')
    plt.legend()
    plt.grid(True)
    plt.show()
