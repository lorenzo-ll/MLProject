# -*- coding: utf-8 -*-
"""
Created on Fri May 10 10:42:24 2024

@author: Lorenzo
"""

############################################################################################
# Copyright (C) 2024 by Sandro Cumani                                                      #
#                                                                                          #
# This file is provided for didactic purposes only, according to the Politecnico di Torino #
# policies on didactic material.                                                           #
#                                                                                          #
# Any form of re-distribution or online publication is forbidden.                          #
#                                                                                          #
# This file is provided as-is, without any warranty                                        #
############################################################################################

import numpy
def vcol(x): # Same as in pca script
    return x.reshape((x.size, 1))

def vrow(x): # Same as in pca script
    return x.reshape((1, x.size))

def load(fname):
    DList = []
    labelsList = []
    hLabels = {
        '0': 0,
        '1': 1
        }

    with open(fname) as f:
        for line in f:
            try:
                attrs = line.split(',')[0:-1]
                attrs = vcol(numpy.array([float(i) for i in attrs]))
                name = line.split(',')[-1].strip()
                label = hLabels[name]
                DList.append(attrs)
                labelsList.append(label)
            except:
                pass

    return numpy.hstack(DList), numpy.array(labelsList, dtype=numpy.int32)


def plot_hist(D, L):

    D1 = D[:, L==0]
    D2 = D[:, L==1]

    hFea = {
        0: 'Prova',
        }

    for dIdx in range(1):
        plt.figure()
        plt.xlabel(hFea[dIdx])
        plt.hist(D1[dIdx, :], bins = 20, density = True, alpha = 0.4, label = 'True')
        plt.hist(D2[dIdx, :], bins = 20, density = True, alpha = 0.4, label = 'False')
        
        plt.legend()
        plt.tight_layout() # Use with non-default font size to keep axis label inside the figure
        #plt.savefig('hist_%d.pdf' % dIdx)
    plt.show()
    
def plot_gauss(D, L):

    D1 = D[:, L==0]
    D2 = D[:, L==1]

    hFea = {
        0: 'Feat1',
        1: 'Feat2',
        2: 'Feat3',
        3: 'Feat4',
        4: 'Feat5',
        5: 'Feat6',
        }
    mu,C = compute_mu_C(D)
    for dIdx in range(6):
        mu1, C1 = compute_mu_C(vrow(D1[dIdx, :]))
        
        mu2, C2 = compute_mu_C(vrow(D2[dIdx, :]))
        plt.figure()
        plt.xlabel(hFea[dIdx])
        plt.hist(D1[dIdx, :].ravel(), bins=100, density=True, alpha = 0.6, label="False")
        XPlot = numpy.linspace(-4.5, 4.5, 1000)
        plt.plot(XPlot.ravel(), numpy.exp(logpdf_GAU_ND(vrow(XPlot), mu1, C1,)), label="False")
        plt.hist(D2[dIdx, :].ravel(), bins=100, alpha = 0.6, density=True, label="True")
        plt.plot(XPlot.ravel(), numpy.exp(logpdf_GAU_ND(vrow(XPlot), mu2, C2)), label="True")
        
        plt.legend()
        plt.tight_layout() # Use with non-default font size to keep axis label inside the figure
        #plt.savefig('hist_%d.pdf' % dIdx)
    plt.show()    

def plot_scatter(D, L):
    
    D0 = D[:, L==0]
    D1 = D[:, L==1]
    D2 = D[:, L==2]

    hFea = {
        0: 'Sepal length',
        1: 'Sepal width',
        2: 'Petal length',
        3: 'Petal width'
        }

    for dIdx1 in range(4):
        for dIdx2 in range(4):
            if dIdx1 == dIdx2:
                continue
            plt.figure()
            plt.xlabel(hFea[dIdx1])
            plt.ylabel(hFea[dIdx2])
            plt.scatter(D0[dIdx1, :], D0[dIdx2, :], label = 'Setosa')
            plt.scatter(D1[dIdx1, :], D1[dIdx2, :], label = 'Versicolor')
            plt.scatter(D2[dIdx1, :], D2[dIdx2, :], label = 'Virginica')
        
            plt.legend()
            plt.tight_layout() # Use with non-default font size to keep axis label inside the figure
            #plt.savefig('scatter_%d_%d.pdf' % (dIdx1, dIdx2))
        plt.show()
def compute_mu_C(D):
    mu = vcol(D.mean(1))
    C = ((D-mu) @ (D-mu).T) / float(D.shape[1])
    return mu, C

# Compute log-density for a single sample x (column vector). The result is a 1-D array with 1 element
def logpdf_GAU_ND_singleSample(x, mu, C):
    P = numpy.linalg.inv(C)
    return -0.5*x.shape[0]*numpy.log(numpy.pi*2) - 0.5*numpy.linalg.slogdet(C)[1] - 0.5 * ((x-mu).T @ P @ (x-mu)).ravel()

# Compute log-densities for N samples, arranged as a MxN matrix X (N stacked column vectors). The result is a 1-D array with N elements, corresponding to the N log-densities
def logpdf_GAU_ND_slow(X, mu, C):
    ll = [logpdf_GAU_ND_singleSample(X[:, i:i+1], mu, C) for i in range(X.shape[1])]
    return numpy.array(ll).ravel()


# Compute log-densities for N samples, arranged as a MxN matrix X (N stacked column vectors). The result is a 1-D array with N elements, corresponding to the N log-densities
def logpdf_GAU_ND_fast(x, mu, C):
    P = numpy.linalg.inv(C)
    return -0.5*x.shape[0]*numpy.log(numpy.pi*2) - 0.5*numpy.linalg.slogdet(C)[1] - 0.5 * ((x-mu) * (P @ (x-mu))).sum(0)

logpdf_GAU_ND = logpdf_GAU_ND_slow

def compute_ll(X, mu, C):
    return logpdf_GAU_ND(X, mu, C).sum()

if __name__ == '__main__':
    
    D,L=load("trainData.txt")
    
    D0 = D[:, L==0]
    D1 = D[:, L==1]
    
    import matplotlib.pyplot as plt
    plot_gauss(D,L)
