import numpy 
import scipy.special
import sklearn.datasets
import Utils
import bayesRisk
import matplotlib.pyplot as plt



def vcol(x):
    return x.reshape((x.size, 1))

def vrow(x):
    return x.reshape((1, x.size))

def expand_features(D):
    """Expand features to include quadratic terms"""
    n_features = D.shape[0]
    D_expanded = []
    for i in range(n_features):
        D_expanded.append(D[i])
        for j in range(i, n_features):
            D_expanded.append(D[i] * D[j])
    return numpy.vstack(D_expanded)

# Optimize SVM
def train_dual_SVM_linear(DTR, LTR, C, K = 1):
    
    ZTR = LTR * 2.0 - 1.0 # Convert labels to +1/-1
    DTR_EXT = numpy.vstack([DTR, numpy.ones((1,DTR.shape[1])) * K])
    H = numpy.dot(DTR_EXT.T, DTR_EXT) * vcol(ZTR) * vrow(ZTR)

    # Dual objective with gradient
    def fOpt(alpha):
        Ha = H @ vcol(alpha)
        loss = 0.5 * (vrow(alpha) @ Ha).ravel() - alpha.sum()
        grad = Ha.ravel() - numpy.ones(alpha.size)
        return loss, grad

    alphaStar, _, _ = scipy.optimize.fmin_l_bfgs_b(fOpt, numpy.zeros(DTR_EXT.shape[1]), bounds = [(0, C) for i in LTR], factr=1.0)
    
    # Primal loss
    def primalLoss(w_hat):
        S = (vrow(w_hat) @ DTR_EXT).ravel()
        return 0.5 * numpy.linalg.norm(w_hat)**2 + C * numpy.maximum(0, 1 - ZTR * S).sum()

    # Compute primal solution for extended data matrix
    w_hat = (vrow(alphaStar) * vrow(ZTR) * DTR_EXT).sum(1)
    
    # Extract w and b - alternatively, we could construct the extended matrix for the samples to score and use directly v
    w, b = w_hat[0:DTR.shape[0]], w_hat[-1] * K # b must be rescaled in case K != 1, since we want to compute w'x + b * K

    primalLoss, dualLoss = primalLoss(w_hat), -fOpt(alphaStar)[0]
    print ('SVM - C %e - K %e - primal loss %e - dual loss %e - duality gap %e' % (C, K, primalLoss, dualLoss, primalLoss - dualLoss))
    
    return w, b

# We create the kernel function. Since the kernel function may need additional parameters, we create a function that creates on the fly the required kernel function
# The inner function will be able to access the arguments of the outer function
def polyKernel(degree, c):
    
    def polyKernelFunc(D1, D2):
        return (numpy.dot(D1.T, D2) + c) ** degree

    return polyKernelFunc

def rbfKernel(gamma):

    def rbfKernelFunc(D1, D2):
        # Fast method to compute all pair-wise distances. Exploit the fact that |x-y|^2 = |x|^2 + |y|^2 - 2 x^T y, combined with broadcasting
        D1Norms = (D1**2).sum(0)
        D2Norms = (D2**2).sum(0)
        Z = vcol(D1Norms) + vrow(D2Norms) - 2 * numpy.dot(D1.T, D2)
        return numpy.exp(-gamma * Z)

    return rbfKernelFunc

# kernelFunc: function that computes the kernel matrix from two data matrices
def train_dual_SVM_kernel(DTR, LTR, C, kernelFunc, eps = 1.0):

    ZTR = LTR * 2.0 - 1.0 # Convert labels to +1/-1
    K = kernelFunc(DTR, DTR) + eps
    H = vcol(ZTR) * vrow(ZTR) * K

    # Dual objective with gradient
    def fOpt(alpha):
        Ha = H @ vcol(alpha)
        loss = 0.5 * (vrow(alpha) @ Ha).ravel() - alpha.sum()
        grad = Ha.ravel() - numpy.ones(alpha.size)
        return loss, grad

    alphaStar, _, _ = scipy.optimize.fmin_l_bfgs_b(fOpt, numpy.zeros(DTR.shape[1]), bounds = [(0, C) for i in LTR], factr=1.0)

    print ('SVM (kernel) - C %e - dual loss %e' % (C, -fOpt(alphaStar)[0]))

    # Function to compute the scores for samples in DTE
    def fScore(DTE):
        
        K = kernelFunc(DTR, DTE) + eps
        H = vcol(alphaStar) * vcol(ZTR) * K
        return H.sum(0)

    return fScore # we directly return the function to score a matrix of test samples

if __name__ == '__main__':
    D, L = Utils.load("trainData.txt")
    
    (DTR, LTR), (DVAL, LVAL) = Utils.split_db_2to1(D, L)
    pt = 0.1
    minDCF_linear = []
    actDCF_linear = []
    minDCF_poly = []
    actDCF_poly = []

    best_linear = {'C': None, 'minDCF': float('inf'), 'actDCF': float('inf')}
    best_poly = {'C': None, 'minDCF': float('inf'), 'actDCF': float('inf')}
    best_rbf = {'gamma': None, 'C': None, 'minDCF': float('inf'), 'actDCF': float('inf')}

    # SVM lineare
    logspace = numpy.logspace(-5, 0, 11)
    for C in logspace:
        w, b = train_dual_SVM_linear(DTR, LTR, C, K=1)
        SVAL = (vrow(w) @ DVAL + b).ravel()
        minDCF = bayesRisk.compute_minDCF_binary_fast(SVAL, LVAL, pt, 1.0, 1.0)
        actDCF = bayesRisk.compute_actDCF_binary_fast(SVAL, LVAL, pt, 1.0, 1.0)
        minDCF_linear.append(minDCF)
        actDCF_linear.append(actDCF)
        if minDCF < best_linear['minDCF']:
            best_linear = {'C': C, 'minDCF': minDCF, 'actDCF': actDCF}
    
    
    # Plotting
    plt.figure(figsize=(10, 6))
    plt.semilogx(logspace, minDCF_linear, label='minDCF', marker='o')
    plt.semilogx(logspace, actDCF_linear, label='actDCF', marker='s')
    plt.xlabel('C')
    plt.ylabel('DCF')
    plt.title('minDCF and actDCF vs C for Linear SVM (πT = 0.1)')
    plt.legend()
    plt.grid(True)
    plt.show()
    print("Best Linear SVM:")
    print(f"C: {best_linear['C']}, minDCF: {best_linear['minDCF']:.4f}, actDCF: {best_linear['actDCF']:.4f}")

    D_expanded = expand_features(D)
    (DTR, LTR), (DVAL, LVAL) = Utils.split_db_2to1(D_expanded, L)
    # SVM con kernel polinomiale (quadratic model)
    for C in logspace:
        kernelFunc = polyKernel(2, 1)
        fScore = train_dual_SVM_kernel(DTR, LTR, C, kernelFunc, eps=0)
        SVAL = fScore(DVAL)
        minDCF = bayesRisk.compute_minDCF_binary_fast(SVAL, LVAL, pt, 1.0, 1.0)
        actDCF = bayesRisk.compute_actDCF_binary_fast(SVAL, LVAL, pt, 1.0, 1.0)
        minDCF_poly.append(minDCF)
        actDCF_poly.append(actDCF)
        if minDCF < best_poly['minDCF']:
            best_poly = {'C': C, 'minDCF': minDCF, 'actDCF': actDCF}
            
    plt.figure(figsize=(10, 6))
    plt.semilogx(logspace, minDCF_linear, label='minDCF', marker='o')
    plt.semilogx(logspace, actDCF_linear, label='actDCF', marker='s')
    plt.xlabel('C')
    plt.ylabel('DCF')
    plt.title('minDCF and actDCF vs C for Poly SVM (πT = 0.1)')
    plt.legend()
    plt.grid(True)
    plt.show()

    print("Best Poly SVM:")
    print(f"C: {best_poly['C']}, minDCF: {best_poly['minDCF']:.4f}, actDCF: {best_poly['actDCF']:.4f}")

    # SVM con kernel RBF
    gamma_values = [1e-4, 1e-3, 1e-2, 1e-1]
    C_values = numpy.logspace(-3, 2, 11)

    for gamma in gamma_values:
        for C in C_values:
            kernel = rbfKernel(gamma)
            fScore = train_dual_SVM_kernel(DTR, LTR, C, kernel, eps=1.0)
            SVAL = fScore(DVAL)
            minDCF = bayesRisk.compute_minDCF_binary_fast(SVAL, LVAL, pt, 1.0, 1.0)
            actDCF = bayesRisk.compute_actDCF_binary_fast(SVAL, LVAL, pt, 1.0, 1.0)
            if minDCF < best_rbf['minDCF']:
                best_rbf = {'gamma': gamma, 'C': C, 'minDCF': minDCF, 'actDCF': actDCF}

    print("Miglior SVM RBF:")
    print(f"gamma: {best_rbf['gamma']}, C: {best_rbf['C']}, minDCF: {best_rbf['minDCF']:.4f}, actDCF: {best_rbf['actDCF']:.4f}")

    # Miglior modello overall
    best_overall = min([best_linear, best_poly, best_rbf], key=lambda x: x['minDCF'])
    best_type = "Lineare" if best_overall == best_linear else "Polinomiale" if best_overall == best_poly else "RBF"

    print("\nBest model overall:")
    print(f"Tipo: SVM {best_type}")
    if best_type == "RBF":
        print(f"gamma: {best_overall['gamma']}, C: {best_overall['C']}")
    else:
        print(f"C: {best_overall['C']}")
    print(f"minDCF: {best_overall['minDCF']:.4f}, actDCF: {best_overall['actDCF']:.4f}")