import numpy as np
import matplotlib.pyplot as plt
import Utils
import bayesRisk
from gmm import *

def expand_features(D):
    """Expand features to include quadratic terms"""
    n_features = D.shape[0]
    D_expanded = []
    for i in range(n_features):
        D_expanded.append(D[i])
        for j in range(i, n_features):
            D_expanded.append(D[i] * D[j])
    return numpy.vstack(D_expanded)

# Optimize SVM
def train_dual_SVM_linear(DTR, LTR, C, K = 1):
    
    ZTR = LTR * 2.0 - 1.0 # Convert labels to +1/-1
    DTR_EXT = numpy.vstack([DTR, numpy.ones((1,DTR.shape[1])) * K])
    H = numpy.dot(DTR_EXT.T, DTR_EXT) * vcol(ZTR) * vrow(ZTR)

    # Dual objective with gradient
    def fOpt(alpha):
        Ha = H @ vcol(alpha)
        loss = 0.5 * (vrow(alpha) @ Ha).ravel() - alpha.sum()
        grad = Ha.ravel() - numpy.ones(alpha.size)
        return loss, grad

    alphaStar, _, _ = scipy.optimize.fmin_l_bfgs_b(fOpt, numpy.zeros(DTR_EXT.shape[1]), bounds = [(0, C) for i in LTR], factr=1.0)
    
    # Primal loss
    def primalLoss(w_hat):
        S = (vrow(w_hat) @ DTR_EXT).ravel()
        return 0.5 * numpy.linalg.norm(w_hat)**2 + C * numpy.maximum(0, 1 - ZTR * S).sum()

    # Compute primal solution for extended data matrix
    w_hat = (vrow(alphaStar) * vrow(ZTR) * DTR_EXT).sum(1)
    
    # Extract w and b - alternatively, we could construct the extended matrix for the samples to score and use directly v
    w, b = w_hat[0:DTR.shape[0]], w_hat[-1] * K # b must be rescaled in case K != 1, since we want to compute w'x + b * K

    primalLoss, dualLoss = primalLoss(w_hat), -fOpt(alphaStar)[0]
    print ('SVM - C %e - K %e - primal loss %e - dual loss %e - duality gap %e' % (C, K, primalLoss, dualLoss, primalLoss - dualLoss))
    
    return w, b

# We create the kernel function. Since the kernel function may need additional parameters, we create a function that creates on the fly the required kernel function
# The inner function will be able to access the arguments of the outer function
def polyKernel(degree, c):
    
    def polyKernelFunc(D1, D2):
        return (numpy.dot(D1.T, D2) + c) ** degree

    return polyKernelFunc

def rbfKernel(gamma):

    def rbfKernelFunc(D1, D2):
        # Fast method to compute all pair-wise distances. Exploit the fact that |x-y|^2 = |x|^2 + |y|^2 - 2 x^T y, combined with broadcasting
        D1Norms = (D1**2).sum(0)
        D2Norms = (D2**2).sum(0)
        Z = vcol(D1Norms) + vrow(D2Norms) - 2 * numpy.dot(D1.T, D2)
        return numpy.exp(-gamma * Z)

    return rbfKernelFunc

# kernelFunc: function that computes the kernel matrix from two data matrices
def train_dual_SVM_kernel(DTR, LTR, C, kernelFunc, eps = 1.0):

    ZTR = LTR * 2.0 - 1.0 # Convert labels to +1/-1
    K = kernelFunc(DTR, DTR) + eps
    H = vcol(ZTR) * vrow(ZTR) * K

    # Dual objective with gradient
    def fOpt(alpha):
        Ha = H @ vcol(alpha)
        loss = 0.5 * (vrow(alpha) @ Ha).ravel() - alpha.sum()
        grad = Ha.ravel() - numpy.ones(alpha.size)
        return loss, grad

    alphaStar, _, _ = scipy.optimize.fmin_l_bfgs_b(fOpt, numpy.zeros(DTR.shape[1]), bounds = [(0, C) for i in LTR], factr=1.0)

    print ('SVM (kernel) - C %e - dual loss %e' % (C, -fOpt(alphaStar)[0]))

    # Function to compute the scores for samples in DTE
    def fScore(DTE):
        
        K = kernelFunc(DTR, DTE) + eps
        H = vcol(alphaStar) * vcol(ZTR) * K
        return H.sum(0)

    return fScore # we directly return the function to score a matrix of test samples

# Optimize the logistic regression loss
def trainLogRegBinary(DTR, LTR, l):

    ZTR = LTR * 2.0 - 1.0 # We do it outside the objective function, since we only need to do it once

    def logreg_obj_with_grad(v): # We compute both the objective and its gradient to speed up the optimization
        w = v[:-1]
        b = v[-1]
        s = numpy.dot(vcol(w).T, DTR).ravel() + b

        loss = numpy.logaddexp(0, -ZTR * s)

        G = -ZTR / (1.0 + numpy.exp(ZTR * s))
        GW = (vrow(G) * DTR).mean(1) + l * w.ravel()
        Gb = G.mean()
        return loss.mean() + l / 2 * numpy.linalg.norm(w)**2, numpy.hstack([GW, numpy.array(Gb)])

    vf = scipy.optimize.fmin_l_bfgs_b(logreg_obj_with_grad, x0 = numpy.zeros(DTR.shape[0]+1))[0]
    print ("Log-reg - lambda = %e - J*(w, b) = %e" % (l, logreg_obj_with_grad(vf)[0]))
    return vf[:-1], vf[-1]

# Optimize the weighted logistic regression loss
def trainWeightedLogRegBinary(DTR, LTR, l, pT):

    ZTR = LTR * 2.0 - 1.0 # We do it outside the objective function, since we only need to do it once
    
    wTrue = pT / (ZTR>0).sum() # Compute the weights for the two classes
    wFalse = (1-pT) / (ZTR<0).sum()

    def logreg_obj_with_grad(v): # We compute both the objective and its gradient to speed up the optimization
        w = v[:-1]
        b = v[-1]
        s = numpy.dot(vcol(w).T, DTR).ravel() + b

        loss = numpy.logaddexp(0, -ZTR * s)
        loss[ZTR>0] *= wTrue # Apply the weights to the loss computations
        loss[ZTR<0] *= wFalse

        G = -ZTR / (1.0 + numpy.exp(ZTR * s))
        G[ZTR > 0] *= wTrue # Apply the weights to the gradient computations
        G[ZTR < 0] *= wFalse
        
        GW = (vrow(G) * DTR).sum(1) + l * w.ravel()
        Gb = G.sum()
        return loss.sum() + l / 2 * numpy.linalg.norm(w)**2, numpy.hstack([GW, numpy.array(Gb)])

    vf = scipy.optimize.fmin_l_bfgs_b(logreg_obj_with_grad, x0 = numpy.zeros(DTR.shape[0]+1))[0]
    print ("Weighted Log-reg (pT %e) - lambda = %e - J*(w, b) = %e" % (pT, l, logreg_obj_with_grad(vf)[0]))
    return vf[:-1], vf[-1]

def train_and_evaluate_gmm(DTR, LTR, DVAL):
    best_config = {'numC0': 8, 'numC1': 32, 'covType': 'diagonal'}  # Best combo given previous tests
    
    gmm0 = train_GMM_LBG_EM(DTR[:, LTR==0], best_config['numC0'], covType=best_config['covType'], verbose=False, psiEig=0.01)
    gmm1 = train_GMM_LBG_EM(DTR[:, LTR==1], best_config['numC1'], covType=best_config['covType'], verbose=False, psiEig=0.01)
    
    SLLR = logpdf_GMM(DVAL, gmm1) - logpdf_GMM(DVAL, gmm0)
    
    return SLLR

def train_and_evaluate_lr(DTR, LTR, DVAL):
    best_lambda = 0.0031623  # Best lambda given previous tests
    
    DTR_expanded = expand_features(DTR)
    DVAL_expanded = expand_features(DVAL)
    
    w, b = trainLogRegBinary(DTR_expanded, LTR, best_lambda)
    sVal = np.dot(w.T, DVAL_expanded) + b
    
    return sVal

def train_and_evaluate_svm(DTR, LTR, DVAL):
    best_config = {'C': 0.01, 'kernel': 'poly', 'gamma': 0.01}  # Best parameters given previous tests
    
    DTR_expanded = expand_features(DTR)
    DVAL_expanded = expand_features(DVAL)
    
    if best_config['kernel'] == 'rbf':
        kernelFunc = rbfKernel(best_config['gamma'])
    elif best_config['kernel'] == 'poly':
        kernelFunc = polyKernel(2, 1)
    else:
        raise ValueError("Kernel non supportato")
    
    fScore = train_dual_SVM_kernel(DTR_expanded, LTR, best_config['C'], kernelFunc, eps=1.0)
    SVAL = fScore(DVAL_expanded)
    
    return SVAL

def compute_DCF(scores, labels, prior, cfn, cfp):
    minDCF = bayesRisk.compute_minDCF_binary_fast(scores, labels, prior, cfn, cfp)
    actDCF = bayesRisk.compute_actDCF_binary_fast(scores, labels, prior, cfn, cfp)
    return minDCF, actDCF

def bayesPlot(S, L, left = -4, right = 4, npts = 21):
    
    effPriorLogOdds = numpy.linspace(left, right, npts)
    effPriors = 1.0 / (1.0 + numpy.exp(-effPriorLogOdds))
    actDCF = []
    minDCF = []
    for effPrior in effPriors:
        actDCF.append(bayesRisk.compute_actDCF_binary_fast(S, L, effPrior, 1.0, 1.0))
        minDCF.append(bayesRisk.compute_minDCF_binary_fast(S, L, effPrior, 1.0, 1.0))
    return effPriorLogOdds, actDCF, minDCF

if __name__ == '__main__':
    D, L = Utils.load("trainData.txt")   
    (DTR, LTR), (DVAL, LVAL) = Utils.split_db_2to1(D, L)
    
    gmm_scores = train_and_evaluate_gmm(DTR, LTR, DVAL)
    lr_scores = train_and_evaluate_lr(DTR, LTR, DVAL)
    svm_scores = train_and_evaluate_svm(DTR, LTR, DVAL)
    np.save('gmm_scores.npy', gmm_scores)
    np.save('lr_scores.npy', lr_scores)
    np.save('svm_scores.npy', svm_scores)
    np.save('labels.npy', LVAL)
    
    target_prior = 0.1
    models = {'GMM': gmm_scores, 'Logistic Regression': lr_scores, 'SVM': svm_scores}
    
    print("Confronto dei modelli per l'applicazione target (prior = 0.1):")
    for model_name, scores in models.items():
        minDCF, actDCF = compute_DCF(scores, LVAL, target_prior, 1, 1)
        print(f"{model_name}: minDCF = {minDCF:.4f}, actDCF = {actDCF:.4f}")
    
    # Bayes Error Plot
    
    plt.figure(figsize=(10, 6))
    colors = ['C0', 'C1', 'C2']
    for (model_name, scores), color in zip(models.items(), colors):
           logOdds, actDCF, minDCF = bayesPlot(scores, LVAL)
           plt.plot(logOdds, minDCF, color=color, linestyle='--', label=f'minDCF ({model_name})')
           plt.plot(logOdds, actDCF, color=color, linestyle='-', label=f'actDCF ({model_name})')
       
    plt.xlabel('Log-odds')
    plt.ylabel('DCF')
    plt.title('Bayes Error Plot')
    plt.legend()
    plt.grid(True)
    plt.show()
    