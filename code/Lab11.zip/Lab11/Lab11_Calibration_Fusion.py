import numpy
import bayesRisk
import logReg
import matplotlib
import matplotlib.pyplot as plt
import Lab10_SecondPart as lab
import Utils

def vcol(x):
    return x.reshape((x.size, 1))

def vrow(x):
    return x.reshape((1, x.size))

# Extract i-th fold from a 1-D numpy array (as for the single fold case, we do not need to shuffle scores in this case, but it may be necessary if samples are sorted in peculiar ways to ensure that validation and calibration sets are independent and with similar characteristics   
def extract_train_val_folds_from_ary(X, idx):
    return numpy.hstack([X[jdx::KFOLD] for jdx in range(KFOLD) if jdx != idx]), X[idx::KFOLD]


def bayesPlot(S, L, left = -3, right = 3, npts = 21):
    
    effPriorLogOdds = numpy.linspace(left, right, npts)
    effPriors = 1.0 / (1.0 + numpy.exp(-effPriorLogOdds))
    actDCF = []
    minDCF = []
    for effPrior in effPriors:
        actDCF.append(bayesRisk.compute_actDCF_binary_fast(S, L, effPrior, 1.0, 1.0))
        minDCF.append(bayesRisk.compute_minDCF_binary_fast(S, L, effPrior, 1.0, 1.0))
    return effPriorLogOdds, actDCF, minDCF

if __name__ == '__main__':

     SAMEFIGPLOTS = True # set to False to have 1 figure per plot
    
     gmm_scores = numpy.load('Data/gmm_scores.npy')
     
     svm_scores = numpy.load('Data/svm_scores.npy')
     
     lr_scores = numpy.load('Data/lr_scores.npy')
     
     labels = numpy.load('Data/labels.npy')
     
     
     
     DTR, LTR = Utils.load("trainData.txt")   
     DVAL, LVAL = Utils.load("evalData.txt") 
     print(LVAL.shape)
     gmm_eval_scores = numpy.load('eval_gmm_scores.npy')
     lr_eval_scores = numpy.load('eval_lr_scores.npy')
     svm_eval_scores = numpy.load('eval_svm_scores.npy')
     
     #numpy.save('eval_gmm_scores.npy', gmm_eval_scores)
     
     #numpy.save('eval_lr_scores.npy', lr_eval_scores)
     
     #numpy.save('eval_svm_scores.npy', svm_eval_scores)
     eval_labels=LVAL

     if SAMEFIGPLOTS:
         fig = plt.figure(figsize=(20,15))
         axes = fig.subplots(3,3, sharex='all')
         fig.suptitle('K-fold')
     else:
         axes = numpy.array([ [plt.figure().gca(), plt.figure().gca(), plt.figure().gca()], [plt.figure().gca(), plt.figure().gca(), plt.figure().gca()], [plt.figure().gca(), plt.figure().gca(), plt.figure().gca()]])

     print()
     print('*** K-FOLD ***')
     print()
     
     pT=0.1
     
     KFOLD = 5
     # We start with the computation of the system performance on the calibration set (whole dataset)
     print('GMM: minDCF (0.1) = %.3f - actDCF (0.1) = %.3f' % (
         bayesRisk.compute_minDCF_binary_fast(gmm_scores, labels, pT, 1.0, 1.0),
         bayesRisk.compute_actDCF_binary_fast(gmm_scores, labels, pT, 1.0, 1.0)))

     print('SVM: minDCF (0.2) = %.3f - actDCF (0.2) = %.3f' % (
         bayesRisk.compute_minDCF_binary_fast(svm_scores, labels, pT, 1.0, 1.0),
         bayesRisk.compute_actDCF_binary_fast(svm_scores, labels, pT, 1.0, 1.0)))
     
     print('LR: minDCF (0.2) = %.3f - actDCF (0.2) = %.3f' % (
         bayesRisk.compute_minDCF_binary_fast(lr_scores, labels, pT, 1.0, 1.0),
         bayesRisk.compute_actDCF_binary_fast(lr_scores, labels, pT, 1.0, 1.0)))

     # Comparison of actDCF / minDCF of both systems
     logOdds, actDCF, minDCF = bayesPlot(gmm_scores, labels)
     axes[0,0].plot(logOdds, minDCF, color='C0', linestyle='--', label = 'minDCF')
     axes[0,0].plot(logOdds, actDCF, color='C0', linestyle='-', label = 'actDCF')

     logOdds, actDCF, minDCF = bayesPlot(svm_scores, labels)
     axes[1,0].plot(logOdds, minDCF, color='C1', linestyle='--', label = 'minDCF')
     axes[1,0].plot(logOdds, actDCF, color='C1', linestyle='-', label = 'actDCF')
     
     logOdds, actDCF, minDCF = bayesPlot(lr_scores, labels)
     axes[2,0].plot(logOdds, minDCF, color='C2', linestyle='--', label = 'minDCF')
     axes[2,0].plot(logOdds, actDCF, color='C2', linestyle='-', label = 'actDCF')
     
     axes[0,0].set_ylim(0, 0.8)    
     axes[0,0].legend()

     axes[1,0].set_ylim(0, 0.8)    
     axes[1,0].legend()
     
     axes[2,0].set_ylim(0, 0.8)    
     axes[2,0].legend()
     
     axes[0,0].set_title('GMM - validation - non-calibrated scores')
     axes[1,0].set_title('SVM - validation - non-calibrated scores')
     axes[2,0].set_title('LR - validation - non-calibrated scores')
     
     # We calibrate both systems (independently)

     # System 1
     calibrated_scores_gmm = [] # We will add to the list the scores computed for each fold
     labels_gmm = [] # We need to ensure that we keep the labels aligned with the scores. The simplest thing to do is to just extract each fold label and pool all the fold labels together in the same order as we pool the corresponding scores.

     # We plot the non-calibrated minDCF and actDCF for reference
     logOdds, actDCF, minDCF = bayesPlot(gmm_scores, labels)
     axes[0,1].plot(logOdds, minDCF, color='C0', linestyle='--', label = 'minDCF (pre-cal.)')
     axes[0,1].plot(logOdds, actDCF, color='C0', linestyle=':', label = 'actDCF (pre-cal.)')
     print ('GMM')
     print ('\tValidation set')
     print ('\t\tminDCF(p=0.1), no cal.: %.3f' % bayesRisk.compute_minDCF_binary_fast(gmm_scores, labels, pT, 1.0, 1.0)) # Calibration may change minDCF due to being fold-dependent (thus it's not globally affine anymore)
     print ('\t\tactDCF(p=0.1), no cal.: %.3f' % bayesRisk.compute_actDCF_binary_fast(gmm_scores, labels, pT, 1.0, 1.0))
     
     pT = 0.1
     # Train KFOLD times the calibration model
     for foldIdx in range(KFOLD):
         # keep 1 fold for validation, use the remaining ones for training
         SCAL, SVAL = extract_train_val_folds_from_ary(gmm_scores, foldIdx)
         LCAL, LVAL = extract_train_val_folds_from_ary(labels, foldIdx)
         # Train the model on the KFOLD - 1 training folds
         w, b = logReg.trainWeightedLogRegBinary(vrow(SCAL), LCAL, 0, pT)
         # Apply the model to the validation fold
         calibrated_SVAL =  (w.T @ vrow(SVAL) + b - numpy.log(pT / (1-pT))).ravel()
         # Add the scores of this validation fold to the cores list
         calibrated_scores_gmm.append(calibrated_SVAL)
         # Add the corresponding labels to preserve alignment between scores and labels
         labels_gmm.append(LVAL)

     # Re-build the score and label arrays (pooling) - these contains an entry for every element in the original dataset (but the order of the samples is different)
     calibrated_scores_gmm = numpy.hstack(calibrated_scores_gmm)
     labels_gmm = numpy.hstack(labels_gmm)

     # Evaluate the performance on pooled scores - we need to use the label vector labels_gmm since it's aligned to calibrated_scores_gmm    
     print ('\t\tminDCF(p=0.1), cal.   : %.3f' % bayesRisk.compute_minDCF_binary_fast(calibrated_scores_gmm, labels_gmm, pT, 1.0, 1.0)) # Calibration may change minDCF due to being fold-dependent (thus it's not globally affine anymore)
     print ('\t\tactDCF(p=0.1), cal.   : %.3f' % bayesRisk.compute_actDCF_binary_fast(calibrated_scores_gmm, labels_gmm, pT, 1.0, 1.0))
     
     logOdds, actDCF, minDCF = bayesPlot(calibrated_scores_gmm, labels_gmm)
     axes[0,1].plot(logOdds, actDCF, color='C0', linestyle='-', label = 'actDCF (cal.)') # NOTE: actDCF of the calibrated pooled scores MAY be lower than the global minDCF we computed earlier, since ache fold is calibrated on its own (thus it's as if we were estimating a possibly different threshold for each fold, whereas minDCF employs a single threshold for all scores)
     axes[0,1].legend()

     axes[0,1].set_title('GMM - validation')
     axes[0,1].set_ylim(0, 0.8)    
     
     # For K-fold the final model is a new model re-trained over the whole set, using the optimal hyperparameters we selected during the k-fold procedure (in this case we have no hyperparameter, so we simply train a new model on the whole dataset)

     w, b = logReg.trainWeightedLogRegBinary(vrow(gmm_scores), labels, 0, pT)
     
     calibrated_eval_scores_gmm = (w.T @ vrow(gmm_eval_scores) + b - numpy.log(pT / (1-pT))).ravel()

     print ('\tEvaluation set')
     print ('\t\tminDCF(p=0.1)         : %.3f' % bayesRisk.compute_minDCF_binary_fast(gmm_eval_scores, eval_labels, pT, 1.0, 1.0))
     print ('\t\tactDCF(p=0.1), no cal.: %.3f' % bayesRisk.compute_actDCF_binary_fast(gmm_eval_scores, eval_labels, pT, 1.0, 1.0))
     print ('\t\tactDCF(p=0.1), cal.   : %.3f' % bayesRisk.compute_actDCF_binary_fast(calibrated_eval_scores_gmm, eval_labels, pT, 1.0, 1.0))    
     
     # We plot minDCF, non-calibrated DCF and calibrated DCF for system 1
     logOdds, actDCF_precal, minDCF = bayesPlot(gmm_eval_scores, eval_labels)
     logOdds, actDCF_cal, _ = bayesPlot(calibrated_eval_scores_gmm, eval_labels) # minDCF is the same
     axes[0,2].plot(logOdds, minDCF, color='C0', linestyle='--', label = 'minDCF')
     axes[0,2].plot(logOdds, actDCF_precal, color='C0', linestyle=':', label = 'actDCF (pre-cal.)')
     axes[0,2].plot(logOdds, actDCF_cal, color='C0', linestyle='-', label = 'actDCF (cal.)')
     axes[0,2].set_ylim(0.0, 0.8)
     axes[0,2].set_title('GMM - evaluation')
     axes[0,2].legend()
     
     
     # svm
     calibrated_scores_svm = [] # We will add to the list the scores computed for each fold
     labels_svm = [] # We need to ensure that we keep the labels aligned with the scores. The simplest thing to do is to just extract each fold label and pool all the fold labels together in the same order as we pool the corresponding scores.

     # We plot the non-calibrated minDCF and actDCF for reference
     logOdds, actDCF, minDCF = bayesPlot(svm_scores, labels)
     axes[1,1].plot(logOdds, minDCF, color='C1', linestyle='--', label = 'minDCF (pre-cal.)')
     axes[1,1].plot(logOdds, actDCF, color='C1', linestyle=':', label = 'actDCF (pre-cal.)')
     print ('SVM')
     print ('\tValidation set')
     print ('\t\tminDCF(p=0.1), no cal.: %.3f' % bayesRisk.compute_minDCF_binary_fast(svm_scores, labels, pT, 1.0, 1.0)) # Calibration may change minDCF due to being fold-dependent (thus it's not globally affine anymore)
     print ('\t\tactDCF(p=0.1), no cal.: %.3f' % bayesRisk.compute_actDCF_binary_fast(svm_scores, labels, pT, 1.0, 1.0))
     
     pT = 0.1
     # Train KFOLD times the calibration model
     for foldIdx in range(KFOLD):
         # keep 1 fold for validation, use the remaining ones for training
         SCAL, SVAL = extract_train_val_folds_from_ary(svm_scores, foldIdx)
         LCAL, LVAL = extract_train_val_folds_from_ary(labels, foldIdx)
         # Train the model on the KFOLD - 1 training folds
         w, b = logReg.trainWeightedLogRegBinary(vrow(SCAL), LCAL, 0, pT)
         # Apply the model to the validation fold
         calibrated_SVAL =  (w.T @ vrow(SVAL) + b - numpy.log(pT / (1-pT))).ravel()
         # Add the scores of this validation fold to the cores list
         calibrated_scores_svm.append(calibrated_SVAL)
         # Add the corresponding labels to preserve alignment between scores and labels
         labels_svm.append(LVAL)

     # Re-build the score and label arrays (pooling) - these contains an entry for every element in the original dataset (but the order of the samples is different)
     calibrated_scores_svm = numpy.hstack(calibrated_scores_svm)
     labels_svm = numpy.hstack(labels_svm)

     # Evaluate the performance on pooled scores - we need to use the label vector labels_gmm since it's aligned to calibrated_scores_gmm    
     print ('\t\tminDCF(p=0.1), cal.   : %.3f' % bayesRisk.compute_minDCF_binary_fast(calibrated_scores_svm, labels_svm, pT, 1.0, 1.0)) # Calibration may change minDCF due to being fold-dependent (thus it's not globally affine anymore)
     print ('\t\tactDCF(p=0.1), cal.   : %.3f' % bayesRisk.compute_actDCF_binary_fast(calibrated_scores_svm, labels_svm, pT, 1.0, 1.0))
     
     logOdds, actDCF, minDCF = bayesPlot(calibrated_scores_svm, labels_svm)
     axes[1,1].plot(logOdds, actDCF, color='C1', linestyle='-', label = 'actDCF (cal.)') # NOTE: actDCF of the calibrated pooled scores MAY be lower than the global minDCF we computed earlier, since ache fold is calibrated on its own (thus it's as if we were estimating a possibly different threshold for each fold, whereas minDCF employs a single threshold for all scores)
     axes[1,1].legend()

     axes[1,1].set_title('SVM - validation')
     axes[1,1].set_ylim(0, 0.8)    
     
     # For K-fold the final model is a new model re-trained over the whole set, using the optimal hyperparameters we selected during the k-fold procedure (in this case we have no hyperparameter, so we simply train a new model on the whole dataset)

     w, b = logReg.trainWeightedLogRegBinary(vrow(svm_scores), labels, 0, pT)
     
     calibrated_eval_scores_svm = (w.T @ vrow(svm_eval_scores) + b - numpy.log(pT / (1-pT))).ravel()

     print ('\tEvaluation set')
     print ('\t\tminDCF(p=0.1)         : %.3f' % bayesRisk.compute_minDCF_binary_fast(svm_eval_scores, eval_labels, pT, 1.0, 1.0))
     print ('\t\tactDCF(p=0.1), no cal.: %.3f' % bayesRisk.compute_actDCF_binary_fast(svm_eval_scores, eval_labels, pT, 1.0, 1.0))
     print ('\t\tactDCF(p=0.1), cal.   : %.3f' % bayesRisk.compute_actDCF_binary_fast(calibrated_eval_scores_svm, eval_labels, pT, 1.0, 1.0))    
     
     # We plot minDCF, non-calibrated DCF and calibrated DCF for system 1
     logOdds, actDCF_precal, minDCF = bayesPlot(svm_eval_scores, eval_labels)
     logOdds, actDCF_cal, _ = bayesPlot(calibrated_eval_scores_svm, eval_labels) # minDCF is the same
     axes[1,2].plot(logOdds, minDCF, color='C1', linestyle='--', label = 'minDCF')
     axes[1,2].plot(logOdds, actDCF_precal, color='C1', linestyle=':', label = 'actDCF (pre-cal.)')
     axes[1,2].plot(logOdds, actDCF_cal, color='C1', linestyle='-', label = 'actDCF (cal.)')
     axes[1,2].set_ylim(0.0, 0.8)
     axes[1,2].set_title('SVM - evaluation')
     axes[1,2].legend()
     
     
     # LR
     calibrated_scores_lr = [] # We will add to the list the scores computed for each fold
     labels_lr = [] # We need to ensure that we keep the labels aligned with the scores. The simplest thing to do is to just extract each fold label and pool all the fold labels together in the same order as we pool the corresponding scores.

     # We plot the non-calibrated minDCF and actDCF for reference
     logOdds, actDCF, minDCF = bayesPlot(lr_scores, labels)
     axes[2,1].plot(logOdds, minDCF, color='C2', linestyle='--', label = 'minDCF (pre-cal.)')
     axes[2,1].plot(logOdds, actDCF, color='C2', linestyle=':', label = 'actDCF (pre-cal.)')
     pT = 0.1
     print ('LR')
     print ('\tValidation set')
     print ('\t\tminDCF(p=0.1), no cal.: %.3f' % bayesRisk.compute_minDCF_binary_fast(lr_scores, labels, pT, 1.0, 1.0)) # Calibration may change minDCF due to being fold-dependent (thus it's not globally affine anymore)
     print ('\t\tactDCF(p=0.1), no cal.: %.3f' % bayesRisk.compute_actDCF_binary_fast(lr_scores, labels, pT, 1.0, 1.0))
     
     
     # Train KFOLD times the calibration model
     for foldIdx in range(KFOLD):
         # keep 1 fold for validation, use the remaining ones for training
         SCAL, SVAL = extract_train_val_folds_from_ary(lr_scores, foldIdx)
         LCAL, LVAL = extract_train_val_folds_from_ary(labels, foldIdx)
         # Train the model on the KFOLD - 1 training folds
         w, b = logReg.trainWeightedLogRegBinary(vrow(SCAL), LCAL, 0, pT)
         # Apply the model to the validation fold
         calibrated_SVAL =  (w.T @ vrow(SVAL) + b - numpy.log(pT / (1-pT))).ravel()
         # Add the scores of this validation fold to the cores list
         calibrated_scores_lr.append(calibrated_SVAL)
         # Add the corresponding labels to preserve alignment between scores and labels
         labels_lr.append(LVAL)

     # Re-build the score and label arrays (pooling) - these contains an entry for every element in the original dataset (but the order of the samples is different)
     calibrated_scores_lr = numpy.hstack(calibrated_scores_lr)
     labels_lr = numpy.hstack(labels_lr)

     # Evaluate the performance on pooled scores - we need to use the label vector labels_gmm since it's aligned to calibrated_scores_gmm    
     print ('\t\tminDCF(p=0.1), cal.   : %.3f' % bayesRisk.compute_minDCF_binary_fast(calibrated_scores_lr, labels_lr, pT, 1.0, 1.0)) # Calibration may change minDCF due to being fold-dependent (thus it's not globally affine anymore)
     print ('\t\tactDCF(p=0.1), cal.   : %.3f' % bayesRisk.compute_actDCF_binary_fast(calibrated_scores_lr, labels_lr, pT, 1.0, 1.0))
     
     logOdds, actDCF, minDCF = bayesPlot(calibrated_scores_lr, labels_lr)
     axes[2,1].plot(logOdds, actDCF, color='C2', linestyle='-', label = 'actDCF (cal.)') # NOTE: actDCF of the calibrated pooled scores MAY be lower than the global minDCF we computed earlier, since ache fold is calibrated on its own (thus it's as if we were estimating a possibly different threshold for each fold, whereas minDCF employs a single threshold for all scores)
     axes[2,1].legend()

     axes[2,1].set_title('LR - validation')
     axes[2,1].set_ylim(0, 0.8)    
     
     # For K-fold the final model is a new model re-trained over the whole set, using the optimal hyperparameters we selected during the k-fold procedure (in this case we have no hyperparameter, so we simply train a new model on the whole dataset)

     w, b = logReg.trainWeightedLogRegBinary(vrow(lr_scores), labels, 0, pT)
     
     # We can use the trained model for application / evaluation data
     calibrated_eval_scores_lr = (w.T @ vrow(lr_eval_scores) + b - numpy.log(pT / (1-pT))).ravel()

     print ('\tEvaluation set')
     print ('\t\tminDCF(p=0.1)         : %.3f' % bayesRisk.compute_minDCF_binary_fast(lr_eval_scores, eval_labels, pT, 1.0, 1.0))
     print ('\t\tactDCF(p=0.1), no cal.: %.3f' % bayesRisk.compute_actDCF_binary_fast(lr_eval_scores, eval_labels, pT, 1.0, 1.0))
     print ('\t\tactDCF(p=0.1), cal.   : %.3f' % bayesRisk.compute_actDCF_binary_fast(calibrated_eval_scores_lr, eval_labels, pT, 1.0, 1.0))    
     
     # We plot minDCF, non-calibrated DCF and calibrated DCF for system 1
     logOdds, actDCF_precal, minDCF = bayesPlot(lr_eval_scores, eval_labels)
     logOdds, actDCF_cal, _ = bayesPlot(calibrated_eval_scores_lr, eval_labels) # minDCF is the same
     axes[2,2].plot(logOdds, minDCF, color='C2', linestyle='--', label = 'minDCF')
     axes[2,2].plot(logOdds, actDCF_precal, color='C2', linestyle=':', label = 'actDCF (pre-cal.)')
     axes[2,2].plot(logOdds, actDCF_cal, color='C2', linestyle='-', label = 'actDCF (cal.)')
     axes[2,2].set_ylim(0.0, 0.8)
     axes[2,2].set_title('LR - evaluation')
     axes[2,2].legend()
     
     
     # Fusion #
     
     fusedScores = [] # We will add to the list the scores computed for each fold
     fusedLabels = [] # We need to ensure that we keep the labels aligned with the scores. The simplest thing to do is to just extract each fold label and pool all the fold labels together in the same order as we pool the corresponding scores.
     
     pT = 0.1
     
     # Train KFOLD times the fusion model
     for foldIdx in range(KFOLD):
         # keep 1 fold for validation, use the remaining ones for training        
         SCAL1, SVAL1 = extract_train_val_folds_from_ary(gmm_scores, foldIdx)
         SCAL2, SVAL2 = extract_train_val_folds_from_ary(svm_scores, foldIdx)
         SCAL3, SVAL3 = extract_train_val_folds_from_ary(lr_scores, foldIdx)
         LCAL, LVAL = extract_train_val_folds_from_ary(labels, foldIdx)
         # Build the training scores "feature" matrix
         SCAL = numpy.vstack([SCAL1, SCAL2,SCAL3])
         # Train the model on the KFOLD - 1 training folds
         w, b = logReg.trainWeightedLogRegBinary(SCAL, LCAL, 0, pT)
         # Build the validation scores "feature" matrix
         SVAL = numpy.vstack([SVAL1, SVAL2, SVAL3])
         # Apply the model to the validation fold
         calibrated_SVAL =  (w.T @ SVAL + b - numpy.log(pT / (1-pT))).ravel()
         # Add the scores of this validation fold to the cores list
         fusedScores.append(calibrated_SVAL)
         # Add the corresponding labels to preserve alignment between scores and labels
         fusedLabels.append(LVAL)

     # Re-build the score and label arrays (pooling) - these contains an entry for every element in the original dataset (but the order of the samples is different)        
     fusedScores = numpy.hstack(fusedScores)
     fusedLabels = numpy.hstack(fusedLabels)

     # Evaluate the performance on pooled scores - we need to use the label vector fusedLabels since it's aligned to calScores_sys_2 (plot on same figure as system 1 and system 2)

     print ('Fusion')
     print ('\tValidation set')
     print ('\t\tminDCF(p=0.1)         : %.3f' % bayesRisk.compute_minDCF_binary_fast(fusedScores, fusedLabels, pT, 1.0, 1.0)) # Calibration may change minDCF due to being fold-dependent (thus it's not globally affine anymore)
     print ('\t\tactDCF(p=0.1)         : %.3f' % bayesRisk.compute_actDCF_binary_fast(fusedScores, fusedLabels, pT, 1.0, 1.0))

     # As comparison, we select calibrated models trained with prior 0.2 (our target application)
     logOdds, actDCF, minDCF = bayesPlot(calibrated_scores_gmm, labels_gmm)
     plt.figure(figsize=(16, 9))
     plt.title('Fusion - validation')
     plt.plot(logOdds, minDCF, color='C0', linestyle='--', label = 'GMM - minDCF')
     plt.plot(logOdds, actDCF, color='C0', linestyle='-', label = 'GMM - actDCF')
     logOdds, actDCF, minDCF = bayesPlot(calibrated_scores_svm, labels_svm)
     plt.plot(logOdds, minDCF, color='C1', linestyle='--', label = 'SVM - minDCF')
     plt.plot(logOdds, actDCF, color='C1', linestyle='-', label = 'SVM - actDCF') 
     logOdds, actDCF, minDCF = bayesPlot(calibrated_scores_lr, labels_lr)
     plt.plot(logOdds, minDCF, color='C2', linestyle='--', label = 'LR - minDCF')
     plt.plot(logOdds, actDCF, color='C2', linestyle='-', label = 'LR - actDCF')
     plt.figure(figsize=(16, 9))
     plt.title('Fusion - validation')
     logOdds, actDCF, minDCF = bayesPlot(fusedScores, fusedLabels)
     plt.plot(logOdds, minDCF, color='C3', linestyle='--', label = 'GMM+SVM+LR - KFold - minDCF(0.1)')
     plt.plot(logOdds, actDCF, color='C3', linestyle='-', label = 'GMM+SVM+LR - KFold - actDCF(0.1)')
     plt.ylim(0.0, 0.8)
     plt.legend()

     # For K-fold the final model is a new model re-trained over the whole set, using the optimal hyperparameters we selected during the k-fold procedure (in this case we have no hyperparameter, so we simply train a new model on the whole dataset)

     SMatrix = numpy.vstack([gmm_scores, svm_scores,lr_scores])
     w, b = logReg.trainWeightedLogRegBinary(SMatrix, labels, 0, pT)
     
     # Apply model to application / evaluation data
     SMatrixEval = numpy.vstack([gmm_eval_scores, svm_eval_scores, lr_eval_scores])
     fused_eval_scores = (w.T @ SMatrixEval + b - numpy.log(pT / (1-pT))).ravel()
     print (fused_eval_scores.shape)
     print (eval_labels.shape)

     print ('\tEvaluation set')
     print ('\t\tminDCF(p=0.1)         : %.3f' % bayesRisk.compute_minDCF_binary_fast(fused_eval_scores, eval_labels, pT, 1.0, 1.0))
     print ('\t\tactDCF(p=0.1)         : %.3f' % bayesRisk.compute_actDCF_binary_fast(fused_eval_scores, eval_labels, pT, 1.0, 1.0))
     
     # We plot minDCF, actDCF for calibrated system 1, calibrated system 2 and fusion
     logOdds, actDCF, minDCF = bayesPlot(calibrated_eval_scores_gmm, eval_labels)
     plt.figure(figsize=(16, 9))
     plt.title('Fusion - evaluation')
     plt.plot(logOdds, minDCF, color='C0', linestyle='--', label = 'GMM - minDCF')
     plt.plot(logOdds, actDCF, color='C0', linestyle='-', label = 'GMM - actDCF')
     logOdds, actDCF, minDCF = bayesPlot(calibrated_eval_scores_svm, eval_labels)
     plt.plot(logOdds, minDCF, color='C1', linestyle='--', label = 'SVM - minDCF')
     plt.plot(logOdds, actDCF, color='C1', linestyle='-', label = 'SVM - actDCF')
     
     logOdds, actDCF, minDCF = bayesPlot(calibrated_eval_scores_lr, eval_labels)
     plt.plot(logOdds, minDCF, color='C2', linestyle='--', label = 'LR - minDCF')
     plt.plot(logOdds, actDCF, color='C2', linestyle='-', label = 'LR - actDCF')
     plt.figure(figsize=(16, 9))
     plt.title('Fusion - evaluation')
     logOdds, actDCF, minDCF = bayesPlot(fused_eval_scores, eval_labels) # minDCF is the same
     plt.plot(logOdds, minDCF, color='C3', linestyle='--', label = 'GMM + SVM + LR - minDCF')
     plt.plot(logOdds, actDCF, color='C3', linestyle='-', label = 'GMM + SVM + LR - actDCF')
     plt.ylim(0.0, 0.8)
     #plt.set_title('Fusion - evaluation')
     plt.legend()
     
     plt.show()

     
     