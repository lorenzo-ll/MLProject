import numpy
import bayesRisk
import logReg
import matplotlib
import matplotlib.pyplot as plt
import Lab10_SecondPart as lab
import Utils

def vcol(x):
    return x.reshape((x.size, 1))

def vrow(x):
    return x.reshape((1, x.size))

# Extract i-th fold from a 1-D numpy array (as for the single fold case, we do not need to shuffle scores in this case, but it may be necessary if samples are sorted in peculiar ways to ensure that validation and calibration sets are independent and with similar characteristics   
def extract_train_val_folds_from_ary(X, idx):
    return numpy.hstack([X[jdx::KFOLD] for jdx in range(KFOLD) if jdx != idx]), X[idx::KFOLD]


def bayesPlot(S, L, left = -3, right = 3, npts = 21):
    
    effPriorLogOdds = numpy.linspace(left, right, npts)
    effPriors = 1.0 / (1.0 + numpy.exp(-effPriorLogOdds))
    actDCF = []
    minDCF = []
    for effPrior in effPriors:
        actDCF.append(bayesRisk.compute_actDCF_binary_fast(S, L, effPrior, 1.0, 1.0))
        minDCF.append(bayesRisk.compute_minDCF_binary_fast(S, L, effPrior, 1.0, 1.0))
    return effPriorLogOdds, actDCF, minDCF

if __name__ == '__main__':

     SAMEFIGPLOTS = True # set to False to have 1 figure per plot
    
     gmm_scores = numpy.load('Data/gmm_scores.npy')
     
     svm_scores = numpy.load('Data/svm_scores.npy')
     
     lr_scores = numpy.load('Data/lr_scores.npy')
     
     labels = numpy.load('Data/labels.npy')
     
     
     
     DTR, LTR = Utils.load("trainData.txt")   
     DVAL, LVAL = Utils.load("evalData.txt") 
     print(LVAL.shape)
     #gmm_eval_scores = numpy.load('eval_gmm_scores.npy')
     #lr_eval_scores = numpy.load('eval_lr_scores.npy')
     #svm_eval_scores = numpy.load('eval_svm_scores.npy')
     gmm_eval_scores = lab.train_and_evaluate_gmm(DTR, LTR, DVAL)
     print(gmm_eval_scores.shape)
     print("done gmm")
     lr_eval_scores = lab.train_and_evaluate_lr(DTR, LTR, DVAL)
     print(lr_eval_scores.shape)
     print("done lr")
     svm_eval_scores = lab.train_and_evaluate_svm(DTR, LTR, DVAL)
     print(svm_eval_scores.shape)
     print("done svm")
     #numpy.save('eval_gmm_scores.npy', gmm_scores)
     
     #numpy.save('eval_lr_scores.npy', lr_scores)
     
     #numpy.save('eval_svm_scores.npy', svm_scores)
     eval_labels=LVAL

     if SAMEFIGPLOTS:
         fig = plt.figure(figsize=(20,15))
         axes = fig.subplots(1,1, sharex='all')
         fig.suptitle('K-fold')
     else:
         axes = numpy.array([ [None, plt.figure().gca(), plt.figure().gca()] ])

     print()
     print('*** K-FOLD ***')
     print()
     
     pT=0.1
     
     KFOLD = 5
     
     # Fusion #
     
     fusedScores = [] # We will add to the list the scores computed for each fold
     fusedLabels = [] # We need to ensure that we keep the labels aligned with the scores. The simplest thing to do is to just extract each fold label and pool all the fold labels together in the same order as we pool the corresponding scores.
     
     pT = 0.1
     
     # Train KFOLD times the fusion model
     for foldIdx in range(KFOLD):
         # keep 1 fold for validation, use the remaining ones for training        
         SCAL1, SVAL1 = extract_train_val_folds_from_ary(gmm_scores, foldIdx)
         SCAL2, SVAL2 = extract_train_val_folds_from_ary(svm_scores, foldIdx)
         SCAL3, SVAL3 = extract_train_val_folds_from_ary(lr_scores, foldIdx)
         LCAL, LVAL = extract_train_val_folds_from_ary(labels, foldIdx)
         # Build the training scores "feature" matrix
         SCAL = numpy.vstack([SCAL1, SCAL2,SCAL3])
         # Train the model on the KFOLD - 1 training folds
         w, b = logReg.trainWeightedLogRegBinary(SCAL, LCAL, 0, pT)
         # Build the validation scores "feature" matrix
         SVAL = numpy.vstack([SVAL1, SVAL2, SVAL3])
         # Apply the model to the validation fold
         calibrated_SVAL =  (w.T @ SVAL + b - numpy.log(pT / (1-pT))).ravel()
         # Add the scores of this validation fold to the cores list
         fusedScores.append(calibrated_SVAL)
         # Add the corresponding labels to preserve alignment between scores and labels
         fusedLabels.append(LVAL)

     # Re-build the score and label arrays (pooling) - these contains an entry for every element in the original dataset (but the order of the samples is different)        
     fusedScores = numpy.hstack(fusedScores)
     fusedLabels = numpy.hstack(fusedLabels)

     # Evaluate the performance on pooled scores - we need to use the label vector fusedLabels since it's aligned to calScores_sys_2 (plot on same figure as system 1 and system 2)

     print ('Fusion')
     print ('\tValidation set')
     print ('\t\tminDCF(p=0.1)         : %.3f' % bayesRisk.compute_minDCF_binary_fast(fusedScores, fusedLabels, pT, 1.0, 1.0)) # Calibration may change minDCF due to being fold-dependent (thus it's not globally affine anymore)
     print ('\t\tactDCF(p=0.1)         : %.3f' % bayesRisk.compute_actDCF_binary_fast(fusedScores, fusedLabels, pT, 1.0, 1.0))

     # As comparison, we select calibrated models trained with prior 0.2 (our target application)
     logOdds, actDCF, minDCF = bayesPlot(calibrated_scores_gmm, labels_gmm)
     axes[3,1].set_title('Fusion - validation')
     axes[3,1].plot(logOdds, minDCF, color='C0', linestyle='--', label = 'GMM - minDCF')
     axes[3,1].plot(logOdds, actDCF, color='C0', linestyle='-', label = 'GMM - actDCF')
     logOdds, actDCF, minDCF = bayesPlot(calibrated_scores_svm, labels_svm)
     axes[3,1].plot(logOdds, minDCF, color='C1', linestyle='--', label = 'SVM - minDCF')
     axes[3,1].plot(logOdds, actDCF, color='C1', linestyle='-', label = 'SVM - actDCF') 
     logOdds, actDCF, minDCF = bayesPlot(calibrated_scores_lr, labels_lr)
     axes[3,1].plot(logOdds, minDCF, color='C2', linestyle='--', label = 'LR - minDCF')
     axes[3,1].plot(logOdds, actDCF, color='C2', linestyle='-', label = 'LR - actDCF')
     
     logOdds, actDCF, minDCF = bayesPlot(fusedScores, fusedLabels)
     axes[3,1].plot(logOdds, minDCF, color='C3', linestyle='--', label = 'GMM+SVM+LR - KFold - minDCF(0.1)')
     axes[3,1].plot(logOdds, actDCF, color='C3', linestyle='-', label = 'GMM+SVM+LR - KFold - actDCF(0.1)')
     axes[3,1].set_ylim(0.0, 0.8)
     axes[3,1].legend()

     # For K-fold the final model is a new model re-trained over the whole set, using the optimal hyperparameters we selected during the k-fold procedure (in this case we have no hyperparameter, so we simply train a new model on the whole dataset)

     SMatrix = numpy.vstack([gmm_scores, svm_scores,lr_scores])
     w, b = logReg.trainWeightedLogRegBinary(SMatrix, labels, 0, pT)
     
     # Apply model to application / evaluation data
     SMatrixEval = numpy.vstack([gmm_scores, svm_scores,lr_scores])
     fused_eval_scores = (w.T @ SMatrixEval + b - numpy.log(pT / (1-pT))).ravel()
     print (fused_eval_scores.shape)
     print (eval_labels.shape)

     print ('\tEvaluation set')
     print ('\t\tminDCF(p=0.1)         : %.3f' % bayesRisk.compute_minDCF_binary_fast(fused_eval_scores, eval_labels, pT, 1.0, 1.0))
     print ('\t\tactDCF(p=0.1)         : %.3f' % bayesRisk.compute_actDCF_binary_fast(fused_eval_scores, eval_labels, pT, 1.0, 1.0))
     
     # We plot minDCF, actDCF for calibrated system 1, calibrated system 2 and fusion
     logOdds, actDCF, minDCF = bayesPlot(calibrated_eval_scores_gmm, eval_labels)
     axes[3,2].plot(logOdds, minDCF, color='C0', linestyle='--', label = 'GMM - minDCF')
     axes[3,2].plot(logOdds, actDCF, color='C0', linestyle='-', label = 'GMM - actDCF')
     logOdds, actDCF, minDCF = bayesPlot(calibrated_eval_scores_svm, eval_labels)
     axes[3,2].plot(logOdds, minDCF, color='C1', linestyle='--', label = 'SVM - minDCF')
     axes[3,2].plot(logOdds, actDCF, color='C1', linestyle='-', label = 'SVM - actDCF')
     
     logOdds, actDCF, minDCF = bayesPlot(calibrated_eval_scores_lr, eval_labels)
     axes[3,2].plot(logOdds, minDCF, color='C2', linestyle='--', label = 'LR - minDCF')
     axes[3,2].plot(logOdds, actDCF, color='C2', linestyle='-', label = 'LR - actDCF')
     
     logOdds, actDCF, minDCF = bayesPlot(fused_eval_scores, eval_labels) # minDCF is the same
     axes[3,2].plot(logOdds, minDCF, color='C2', linestyle='--', label = 'GMM + SVM + LR - minDCF')
     axes[3,2].plot(logOdds, actDCF, color='C2', linestyle='-', label = 'GMM + SVM + LR - actDCF')
     axes[3,2].set_ylim(0.0, 0.8)
     axes[3,2].set_title('Fusion - evaluation')
     axes[3,2].legend()
     
     plt.show()

     
     