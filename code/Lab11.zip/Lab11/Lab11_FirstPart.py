import numpy
import bayesRisk
import logReg
import matplotlib
import matplotlib.pyplot as plt

def vcol(x):
    return x.reshape((x.size, 1))

def vrow(x):
    return x.reshape((1, x.size))

def bayesPlot(S, L, left = -4, right = 4, npts = 21):
    
    effPriorLogOdds = numpy.linspace(left, right, npts)
    effPriors = 1.0 / (1.0 + numpy.exp(-effPriorLogOdds))
    actDCF = []
    minDCF = []
    for effPrior in effPriors:
        actDCF.append(bayesRisk.compute_actDCF_binary_fast(S, L, effPrior, 1.0, 1.0))
        minDCF.append(bayesRisk.compute_minDCF_binary_fast(S, L, effPrior, 1.0, 1.0))
    return effPriorLogOdds, actDCF, minDCF

if __name__ == '__main__':

    SAMEFIGPLOTS = True # set to False to have 1 figure per plot
    
    gmm_scores = numpy.load('Data/gmm_scores.npy')
    svm_scores = numpy.load('Data/svm_scores.npy')
    lr_scores = numpy.load('Data/lr_scores.npy')
    labels = numpy.load('Data/labels.npy')

    # We analyze the results for the scores of the whole dataset
    pT = 0.1
    print('GMM: minDCF (0.2) = %.3f - actDCF (0.2) = %.3f' % (
        bayesRisk.compute_minDCF_binary_fast(gmm_scores, labels, pT, 1.0, 1.0),
        bayesRisk.compute_actDCF_binary_fast(gmm_scores, labels, pT, 1.0, 1.0)))

    print('SVM: minDCF (0.2) = %.3f - actDCF (0.2) = %.3f' % (
        bayesRisk.compute_minDCF_binary_fast(svm_scores, labels, pT, 1.0, 1.0),
        bayesRisk.compute_actDCF_binary_fast(svm_scores, labels, pT, 1.0, 1.0)))
    
    print('LR: minDCF (0.2) = %.3f - actDCF (0.2) = %.3f' % (
        bayesRisk.compute_minDCF_binary_fast(lr_scores, labels, pT, 1.0, 1.0),
        bayesRisk.compute_actDCF_binary_fast(lr_scores, labels, pT, 1.0, 1.0)))

    # Comparison of actDCF / minDCF of both systems
    plt.figure()
    logOdds, actDCF, minDCF = bayesPlot(gmm_scores, labels)
    plt.plot(logOdds, minDCF, color='C0', linestyle='--', label = 'minDCF (System 1)')
    plt.plot(logOdds, actDCF, color='C0', linestyle='-', label = 'actDCF (System 1)')

    logOdds, actDCF, minDCF = bayesPlot(svm_scores, labels)
    plt.plot(logOdds, minDCF, color='C1', linestyle='--', label = 'minDCF (System 2)')
    plt.plot(logOdds, actDCF, color='C1', linestyle='-', label = 'actDCF (System 2)')
    
    logOdds, actDCF, minDCF = bayesPlot(lr_scores, labels)
    plt.plot(logOdds, minDCF, color='C2', linestyle='--', label = 'minDCF (System 2)')
    plt.plot(logOdds, actDCF, color='C2', linestyle='-', label = 'actDCF (System 2)')
    
    plt.ylim([0, 0.8])
    plt.legend()
    plt.show()