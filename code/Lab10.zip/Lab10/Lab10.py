import numpy as np
import matplotlib.pyplot as plt
import Utils
import bayesRisk

from gmm import *

if __name__ == '__main__':
    D, L = Utils.load("trainData.txt")   
    (DTR, LTR), (DVAL, LVAL) = Utils.split_db_2to1(D, L)
    
    components_range = [1, 2, 4, 8, 16, 32]
    cov_types = ['full', 'diagonal']
    target_prior = 0.1
    
    results = {}
    
    for covType in cov_types:
        results[covType] = {}
        for numC0 in components_range:
            for numC1 in components_range:
                print(f"Training with {covType} covariance, Class 0: {numC0} components, Class 1: {numC1} components")
                
                gmm0 = train_GMM_LBG_EM(DTR[:, LTR==0], numC0, covType=covType, verbose=False, psiEig=0.01)
                gmm1 = train_GMM_LBG_EM(DTR[:, LTR==1], numC1, covType=covType, verbose=False, psiEig=0.01)
                
                SLLR = logpdf_GMM(DVAL, gmm1) - logpdf_GMM(DVAL, gmm0)
                
                minDCF = bayesRisk.compute_minDCF_binary_fast(SLLR, LVAL, target_prior, 1.0, 1.0)
                actDCF = bayesRisk.compute_actDCF_binary_fast(SLLR, LVAL, target_prior, 1.0, 1.0)
                
                results[covType][(numC0, numC1)] = {'minDCF': minDCF, 'actDCF': actDCF}
                
                print(f"\tminDCF: {minDCF:.4f}, actDCF: {actDCF:.4f}")
    
    
    best_config = min(results['full'].items(), key=lambda x: x[1]['minDCF'])
    print(f"Best configuration (full covariance): Class 0: {best_config[0][0]} components, Class 1: {best_config[0][1]} components")
    print(f"minDCF: {best_config[1]['minDCF']:.4f}, actDCF: {best_config[1]['actDCF']:.4f}")

    best_config = min(results['diagonal'].items(), key=lambda x: x[1]['minDCF'])
    print(f"Best configuration (diagonal covariance): Class 0: {best_config[0][0]} components, Class 1: {best_config[0][1]} components")
    print(f"minDCF: {best_config[1]['minDCF']:.4f}, actDCF: {best_config[1]['actDCF']:.4f}")