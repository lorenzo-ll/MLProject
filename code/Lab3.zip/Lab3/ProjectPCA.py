# -*- coding: utf-8 -*-
"""
Created on Tue May  7 15:20:24 2024

@author: Lorenzo
"""
import numpy
import sklearn.datasets 

import matplotlib
import matplotlib.pyplot as plt

import scipy.linalg

def plot_hist(D, L):

    D0 = D[:, L==0]
    D1 = D[:, L==1]
    

    hFea = {
        0: 'Feat 1',
        1: 'Feat 2',
        2: 'Feat 3',
        3: 'Feat 4',
        4: 'Feat 5',
        5: 'Feat 6'
        }

    for dIdx in range(6):
        plt.figure()
        plt.xlabel(hFea[dIdx])
        plt.hist(D0[dIdx, :], bins = 20, density = True, alpha = 0.4, label = 'False')
        plt.hist(D1[dIdx, :], bins = 20, density = True, alpha = 0.4, label = 'True')
        
        plt.legend()
        plt.tight_layout() # Use with non-default font size to keep axis label inside the figure
        #plt.savefig('hist_%d.pdf' % dIdx)
    plt.show()

def plot_scatter(D, L):
    
    D0 = D[:, L==0]
    D1 = D[:, L==1]

    hFea = {
        0: 'Feat 1',
        }

    for dIdx1 in range(6):
        for dIdx2 in range(6):
            if dIdx1 == dIdx2:
                continue
            plt.figure()
            plt.scatter(D0[dIdx1, :], D0[dIdx2, :], label = 'False')
            plt.scatter(D1[dIdx1, :], D1[dIdx2, :], label = 'True')
        
            plt.legend()
            plt.tight_layout() # Use with non-default font size to keep axis label inside the figure
            #plt.savefig('scatter_%d_%d.pdf' % (dIdx1, dIdx2))
        plt.show()

def load(fname):
    DList = []
    labelsList = []
    hLabels = {
        '0': 0,
        '1': 1
        }

    with open(fname) as f:
        for line in f:
            try:
                attrs = line.split(',')[0:-1]
                attrs = vcol(numpy.array([float(i) for i in attrs]))
                name = line.split(',')[-1].strip()
                label = hLabels[name]
                DList.append(attrs)
                labelsList.append(label)
            except:
                pass

    return numpy.hstack(DList), numpy.array(labelsList, dtype=numpy.int32)

def vcol(x):
    return x.reshape((x.size, 1))

def vrow(x):
    return x.reshape((1, x.size))

def compute_mu_C(D):
    mu = vcol(D.mean(1))
    C = ((D-mu) @ (D-mu).T) / float(D.shape[1])
    return mu, C

def compute_pca(D, m):

    mu, C = compute_mu_C(D)
    U, s, Vh = numpy.linalg.svd(C)
    P = U[:, 0:m]
    return P

def apply_pca(P, D):
    return P.T @ D

if __name__ == '__main__':

    D, L = load('trainData.txt')
    #print("STAMPO D \n")
    #print(D)
    #plot_hist(D,L)
    mu, C = compute_mu_C(D)
    P = compute_pca(D, m = 6)
    DP = numpy.dot(P.T, D)
    print("\n STAMPO DP \n")
    print(DP)
    #plot_scatter(DP, L)
    plot_hist(DP,L)